# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['google_documents',
 'google_documents.entities',
 'google_documents.entity_managers',
 'google_documents.tests',
 'google_documents.tests.entities',
 'google_documents.utils']

package_data = \
{'': ['*']}

install_requires = \
['google-api-python-client==1.7.4', 'pandas>=1.2.0,<2.0.0']

setup_kwargs = {
    'name': 'google-documents',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Ken Morishita',
    'author_email': 'mokemokechicken@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
